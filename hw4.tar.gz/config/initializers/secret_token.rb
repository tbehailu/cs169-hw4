# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = '998e8df73f9bac900c4cd7ef0f529612803cf2e22a2fdf06760ccd29a0297fd92e21932450577b214e29e346e68552b24b491dc34c7e31614a44db5274f979e3'
